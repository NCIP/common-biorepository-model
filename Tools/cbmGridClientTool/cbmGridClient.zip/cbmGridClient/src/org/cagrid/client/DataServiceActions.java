package org.cagrid.client;

import gov.nih.nci.cagrid.cqlquery.CQLQuery;
import gov.nih.nci.cagrid.cqlquery.Object;
import gov.nih.nci.cagrid.cqlresultset.CQLQueryResults;
import gov.nih.nci.cagrid.data.client.DataServiceClient;
import gov.nih.nci.cagrid.data.stubs.QueryRequest;
import gov.nih.nci.cagrid.data.stubs.DataServiceResourceProperties;
import gov.nih.nci.cagrid.data.utilities.CQLQueryResultsIterator;

import java.rmi.RemoteException;

import org.apache.axis.message.addressing.EndpointReferenceType;
import org.apache.axis.types.URI.MalformedURIException;
import org.globus.gsi.GlobusCredential;

public class DataServiceActions {
	
	public static CQLQueryResults invokeNonSecureService (EndpointReferenceType epr, String objectName) {
		System.out.println ("Querying: " + objectName);
		
		try {
			DataServiceClient client = new DataServiceClient(epr);

		
			CQLQuery query = new CQLQuery();
			Object target = new Object();
			target.setName(objectName);
			query.setTarget(target);
			
			// execute the query
			CQLQueryResults results = client.query(query);
			CQLQueryResultsIterator iter = new  CQLQueryResultsIterator (results, true);
			
			// here we can cast the returned object to a String because we're 
			// working with XML
			while (iter.hasNext()) {
				String singleResult = (String) iter.next();
				System.out.println(singleResult.toString());
			}
			
			return results;
		} catch (MalformedURIException e) {
			// TODO Display appropriate client error 
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Display appropriate client error 
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Display appropriate client error 
			e.printStackTrace();
		}
		
		return null;
	}
	
	public static CQLQueryResults invokeNonSecureService (EndpointReferenceType epr, CQLQuery query) {
		System.out.println ("Querying non-secure with CQL query");
		
		try {
			DataServiceClient client = new DataServiceClient(epr);
			
			// execute the query
			CQLQueryResults results = client.query(query);

			return results;
		} catch (MalformedURIException e) {
			// TODO Display appropriate client error 
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Display appropriate client error 
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Display appropriate client error 
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	public static CQLQueryResults invokeSecureService (EndpointReferenceType epr, GlobusCredential cred, String objectName) {
		try {
         	System.out.println ("Querying: " + objectName);
         	
			DataServiceClient client = new DataServiceClient(epr, cred);
			CQLQuery query = new CQLQuery();
			Object target = new Object();
			target.setName(objectName);
			query.setTarget(target);
			
			// execute the query
			CQLQueryResults results = client.query(query);
			CQLQueryResultsIterator iter = new CQLQueryResultsIterator (results, true);
	
			// here we can cast the returned object to a String because we're 
			// working with XML
			while (iter.hasNext()) {
				String singleResult = (String) iter.next();
				System.out.println(singleResult.toString());
			}
			
			return results;
	
		} catch (MalformedURIException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	public static CQLQueryResults invokeSecureService (EndpointReferenceType epr, GlobusCredential cred, CQLQuery query) {
		
		try {
         	System.out.println ("Querying with CQL query");
         	 	
			DataServiceClient client = new DataServiceClient(epr, cred);
			
			// execute the query
			CQLQueryResults results = client.query(query);
			
			return results;
	
		} catch (MalformedURIException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}	
	
}

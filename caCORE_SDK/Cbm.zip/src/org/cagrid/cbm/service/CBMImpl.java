package org.cagrid.cbm.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.3
 * 
 */
public class CBMImpl extends CBMImplBase {

	
	public CBMImpl() throws RemoteException {
		super();
	}
	
}


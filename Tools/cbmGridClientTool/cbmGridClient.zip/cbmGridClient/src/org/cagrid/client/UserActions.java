package org.cagrid.client;

import gov.nih.nci.cagrid.authentication.bean.BasicAuthenticationCredential;
import gov.nih.nci.cagrid.authentication.bean.Credential;
import gov.nih.nci.cagrid.metadata.exceptions.ResourcePropertyRetrievalException;
import gov.nih.nci.cagrid.opensaml.SAMLAssertion;

import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.List;
import java.util.ListIterator;

import org.apache.axis.types.URI.MalformedURIException;
import org.cagrid.gaards.authentication.BasicAuthentication;
import org.cagrid.gaards.authentication.client.AuthenticationClient;
import org.cagrid.gaards.dorian.client.DorianClient;
import org.cagrid.gaards.dorian.client.GridUserClient;
import org.cagrid.gaards.dorian.federation.CertificateLifetime;
import org.cagrid.gaards.dorian.federation.GridUser;
import org.cagrid.gaards.dorian.federation.GridUserFilter;
import org.cagrid.gaards.dorian.federation.TrustedIdentityProvider;
import org.cagrid.gaards.dorian.idp.Application;
import org.cagrid.gaards.dorian.idp.CountryCode;
import org.cagrid.gaards.dorian.idp.StateCode;
import org.globus.gsi.GlobusCredential;

public class UserActions {
	private String serviceUrl = null;

	public UserActions (String dorianUrl)  throws MalformedURLException, MalformedURIException, RemoteException{
		this.serviceUrl = dorianUrl;
	}
	
	// Register user against Dorian service
	public boolean registerUser () throws MalformedURIException, RemoteException {
		
		// Create a registration application
		Application userApplication = new Application();
		
		// You should be getting values from your UI here
		userApplication.setUserId( UserInteraction.getUsername() );
		userApplication.setEmail( UserInteraction.getEmail() );
		userApplication.setPassword( UserInteraction.getPassword() );
		userApplication.setFirstName( UserInteraction.getFirstName() );
		userApplication.setLastName( UserInteraction.getLastName() );
		userApplication.setAddress( UserInteraction.getAddress() );
		userApplication.setAddress2( UserInteraction.getAddress2() );
		userApplication.setCity( UserInteraction.getCity() );
		userApplication.setState( StateCode.fromString( UserInteraction.getState() ) );
		userApplication.setCountry( CountryCode.fromString( UserInteraction.getCountry() ) );
		userApplication.setZipcode( UserInteraction.getZipCode() );
		userApplication.setPhoneNumber( UserInteraction.getPhoneNumber() );
		userApplication.setOrganization( UserInteraction.getOrganization() );
	
		// request a local registration using the Dorian client
		DorianClient dorianClient = new DorianClient(this.serviceUrl);
		if ( dorianClient.doesLocalUserExist( userApplication.getUserId()) ) {
			System.out.println("User already registered: " + userApplication.getUserId() );
			return false;
		}
		else {
			dorianClient.registerLocalUser(userApplication);
		}
		
		return true;
	}
	
	// Authenticate User using Dorian clients
	// From: http://www.cagrid.org/display/dorian13/Programmatically+Login+to+Dorian
	public GlobusCredential loginUser () throws Exception{
		String userName = UserInteraction.getUsername();
		String userPass = UserInteraction.getPassword();
					
        // Create credential        
		BasicAuthentication auth = new BasicAuthentication();
        auth.setUserId(userName);
        auth.setPassword(userPass);

        // Authenticate to the IdP (DorianIdP) using credential
        AuthenticationClient authClient = new AuthenticationClient(this.serviceUrl);
        SAMLAssertion saml = authClient.authenticate(auth);

        // Requested Grid Credential lifetime. Dorian defines the maximum as 12 hours.
		String message = "Enter credential lifetime in hours";
		int lifetimeHours = UserInteraction.getIntegerFromUser(message, 1, 12);
		CertificateLifetime lifetime = new CertificateLifetime();
        lifetime.setHours(lifetimeHours);

        // Request PKI/Grid Credential
        GridUserClient dorian = new GridUserClient(this.serviceUrl);
        GlobusCredential credential = dorian.requestUserCertificate(saml, lifetime);
        
        return credential;
	}
	
	public GlobusCredential loginUser (String username, String password) throws MalformedURIException, RemoteException {
		// Create credential        
		BasicAuthentication auth = new BasicAuthentication();
        auth.setUserId(username);
        auth.setPassword(password);

        // Authenticate to the IdP (DorianIdP) using credential
        AuthenticationClient authClient = new AuthenticationClient(this.serviceUrl);
        SAMLAssertion saml = authClient.authenticate(auth);

        // Requested Grid Credential lifetime. Dorian defines the maximum as 12 hours.
		String message = "Enter credential lifetime in hours";
		int lifetimeHours = UserInteraction.getIntegerFromUser(message, 1, 12);
		CertificateLifetime lifetime = new CertificateLifetime();
        lifetime.setHours(lifetimeHours);

        // Request PKI/Grid Credential
        GridUserClient dorian = new GridUserClient(this.serviceUrl);
        GlobusCredential credential = dorian.requestUserCertificate(saml, lifetime);
        
        return credential;
	}
	

	public void getAuthenticationProviders () {
		GridUserClient gridClient;
		try {
			gridClient = new GridUserClient(this.serviceUrl);
			List<TrustedIdentityProvider> idps = gridClient.getTrustedIdentityProviders();
			
			ListIterator<TrustedIdentityProvider> idpIterator = idps.listIterator();
			
			while (idpIterator.hasNext()) {
				TrustedIdentityProvider idp = idpIterator.next();
				String url = idp.getAuthenticationServiceURL();
				String name = idp.getDisplayName();
				System.out.println(name + ": AuthServiceUrl = " + url);
			}
		} catch (MalformedURIException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ResourcePropertyRetrievalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void getUsers (GlobusCredential cred) {
		GridUserClient gridClient;
		try {
			DorianClient client = new DorianClient(this.serviceUrl, cred);
			
			GridUserFilter filter = new GridUserFilter();
			filter.setLastName("Stephens");
			GridUser[] users = client.findGridUsers(filter);
		
			for (int i = 0; i < users.length; i++) {
				GridUser user = users[i];
				System.out.println("Found: " + user.getGridId());
			}
		} catch (MalformedURIException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}

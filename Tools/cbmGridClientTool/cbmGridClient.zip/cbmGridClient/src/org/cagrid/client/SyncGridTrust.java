package org.cagrid.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.Date;

import gov.nih.nci.cagrid.common.Utils;
import gov.nih.nci.cagrid.syncgts.bean.AddedTrustedCAs;
import gov.nih.nci.cagrid.syncgts.bean.Message;
import gov.nih.nci.cagrid.syncgts.bean.Messages;
import gov.nih.nci.cagrid.syncgts.bean.SyncDescription;
import gov.nih.nci.cagrid.syncgts.bean.SyncReport;
import gov.nih.nci.cagrid.syncgts.core.SyncGTS;

public class SyncGridTrust {
	
	private static String globusLocation = System.getProperty("user.home")+File.separator+".globus";
	
	
	// From : http://cagrid.org/display/gts12/Programmatic+Approach
	// Purpose : obtain trusted CA certificates from Slave GTS service
	public static boolean synchronizeOnce(String syncDescriptionFile) {
		
		boolean success = false;
		
		try{
			File sourceLocation = new File("conf"+File.separator+"certificates");
			
	        File targetLocation = new File(System.getProperty("user.home")+File.separator+".globus"+File.separator+"certificates");
	  
			copyCACert(sourceLocation, targetLocation);
			
			//Load Sync Description
			String pathToSyncDescription = syncDescriptionFile; //"conf/training/sync-description.xml";
			SyncDescription description = (SyncDescription) Utils.deserializeDocument(pathToSyncDescription,SyncDescription.class);
					
			//Sync with the Trust Fabric Once
			SyncReport syncReport = SyncGTS.getInstance().syncOnce(description);
			Messages messages = syncReport.getMessages();
			for (int i=0; i < messages.getMessage().length; i++) {
				Message msg =  messages.getMessage(i);
				System.out.println(msg.getValue());
			}
			
			success = true;
			  
		}catch (Exception e) {
			e.printStackTrace();
		}
	
		return success;
	}
	
    // If targetLocation does not exist, it will be created.
    public static void copyCACert(File sourceLocation, File targetLocation)
        throws IOException {
    	
    	// first verify that the .globus is present
    	File globusDir = new File(globusLocation);
    	if (!globusDir.exists()) {
        	System.out.println("Creating Globus Directory");
        	globusDir.mkdir();
        }
    	
        if (sourceLocation.isDirectory()) {
            if (!targetLocation.exists()) {
            	System.out.println("Creating target directory");
                targetLocation.mkdir();
            }        
            
            String[] children = sourceLocation.list();
            for (int i=0; i<children.length; i++) {
            	File targetFile = new File(targetLocation, children[i]);
            	if (!targetFile.exists()) {
            		System.out.println("Copying file: " + children[i]);
            		copyCACert(new File(sourceLocation, children[i]),
            			targetFile);
            	}
            }
        } 
        else {
            
            InputStream in = new FileInputStream(sourceLocation);
            OutputStream out = new FileOutputStream(targetLocation);
            
            // Copy the bits from instream to outstream
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        }
    }
	
}

package org.cagrid.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class UserInteraction {
	
	private static UserInteraction instance = null;
	
	protected UserInteraction() {
	     // Exists only to defeat instantiation.
	}
	 
	public static UserInteraction getInstance() {
	    if(instance == null) {
	    	  instance = new UserInteraction();
	    }
	    return instance;
	}

	public static String getUsername() {
		String username = "";
		
		username = UserInteraction.promptUser("Username");
		
		return username;
	}
	
	public static String getPassword () {
		String password = "";
		
		password = UserInteraction.promptUser("Password");
		
		return password;
	}
	
	public static String getFirstName () {
		String firstName = "";
		
		firstName = UserInteraction.promptUser("FirstName");
		
		return firstName;
	}

	public static String getLastName () {
		String lastName = "";
		
		lastName = UserInteraction.promptUser("LastName");
		
		return lastName;
	}	
	
	
	public static String getEmail () {
		String email = "";
		
		email = UserInteraction.promptUser("EMail");
		
		return email;
	}
	
	public static String getAddress () {
		String address = "";
		
		address = UserInteraction.promptUser("Address");
		
		return address;
	}
	
	public static String getAddress2 () {
		String address2 = "";
		
		address2 = UserInteraction.promptUser("Address");
		
		return address2;
	}
	
	public static String getCity () {
		String city = "";
		
		city = UserInteraction.promptUser("City");
		
		return city;
	}
	
	public static String getState () {
		String state = "";
		
		state = UserInteraction.promptUser("2 Character US State Abbreviation");
		
		return state;
	}
	
	public static String getCountry () {
		String country = "";
		
		country = UserInteraction.promptUser("2 Character Country Code");
		
		return country;
	}
	
	public static String getZipCode () {
		String zipCode = "";
		
		zipCode = UserInteraction.promptUser("Zip Code");
		
		return zipCode;
	}
	
	public static String getPhoneNumber () {
		String phoneNumber = "";
		
		phoneNumber = UserInteraction.promptUser("Phone Number");
		
		return phoneNumber;
	}
	
	public static String getOrganization () {
		String organization  = "";
		
		organization = UserInteraction.promptUser("Organization");
		
		return organization;
	}

	// prompt user for an integer selection
	public static int getIntegerFromUser (String message, int min, int max) {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println(message + " [" + min + ".." + max + "] :");
		
		//  read the input
		int intInput = -1;
		for (;;) {
		try {
				String response = br.readLine();
				intInput = Integer.parseInt(response);

				if (min <= intInput && intInput <= max) {
					break;
				}
				else {
					System.out.println (message);
				}
			} catch (IOException ioe) {
				System.out.println("IO error trying to read your entry!");
			    System.exit(1);
			} catch (NumberFormatException nfe) {
				System.out.println (message);
			}
		}
		
		return intInput;
	}
	
	// prompt user for an String selection
	public static String getStringFromUser (String message) {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println(message + ":");
		
		//  read the input
		String response = "";
		for (;;) {
			try {
				response = br.readLine();

				if (null == response || response.equalsIgnoreCase("")) {
					System.out.println (message);
				}
				else {
					break;
				}
			} catch (IOException ioe) {
				System.out.println("IO error trying to read your entry!");
			    System.exit(1);
			} catch (NumberFormatException nfe) {
				System.out.println (message);
			}
		}
		
		return response;
	}

	public static String promptUser (String fieldName) {
		String fieldValue = "";
		//  open up standard input
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
		System.out.println("Provide " + fieldName + ": ");
		System.out.println();
		
		//  read the input
		try {
			fieldValue = br.readLine();
		} catch (IOException ioe) {
			System.out.println("IO error trying to read your entry!");
		    System.exit(1);
		}
		
		return fieldValue;
		
	}
	
}

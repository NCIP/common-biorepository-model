package org.cagrid.client;

import gov.nih.nci.cagrid.common.Utils;
import gov.nih.nci.cagrid.common.security.ProxyUtil;
import gov.nih.nci.cagrid.cqlquery.CQLQuery;
import gov.nih.nci.cagrid.cqlresultset.CQLQueryResults;
import gov.nih.nci.cagrid.data.DataServiceConstants;
import gov.nih.nci.cagrid.metadata.MetadataUtils;
import gov.nih.nci.cagrid.metadata.dataservice.DomainModel;
import gov.nih.nci.cagrid.metadata.dataservice.UMLClass;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Properties;

import org.apache.axis.AxisFault;
import org.apache.axis.message.addressing.EndpointReferenceType;
import org.apache.axis.types.URI;
import org.apache.axis.types.URI.MalformedURIException;
import org.globus.gsi.GlobusCredential;

/**
 * @author William Stephens
 *
 */
public class GridClient {
	
	private static final String SERVICE_URLS = "conf/service_urls.properties";
	private static final String SYNC_DESCRIPTION  = "conf/sync-description.xml";
	private static final String GRID_CA_CERTIFICATE = "conf/certificates/gridRootCA.0";
	private static final String GRID_CA_SIGNINGPOLICY = "conf/certificates/gridRootCA.signing_policy";
	private static final String DEFAULT_DORIAN_SERVICE_URL_PROP = "cagrid.master.dorian.service.url";
	private static final String DEFAULT_INDEX_SERVICE_URL_PROP = "cagrid.master.index.service.url";
	private static final String DEFAULT_PROXY_FILENAME = "user.proxy";
	
	private static final int QUERY_AGAINST_OBJECT = 1;
	private static final int QUERY_FROM_FILE = 2;
	
	private GlobusCredential cred = null;
	
	private Properties props = null;
	
	public GridClient () {
		props = readProperties();
	}
	

	private static Properties readProperties () {
		Properties properties = new Properties();
        try {
        	properties.load(new FileInputStream(SERVICE_URLS));
        }
        catch (Exception e) {
        	// TODO: Display appropriate client error 
        	System.out.println("Exception while accessing " + SERVICE_URLS + " : " + e.getMessage());
        	System.exit(-1);
        }
        
        return properties;
	}
	
	private void syncTrust () {
		System.out.println("Synchronize Once...");
		System.out.println("Sync file = " + SYNC_DESCRIPTION);
		SyncGridTrust.synchronizeOnce( SYNC_DESCRIPTION );
		System.out.println("Synchronize Complete.");
	}
	
	private void loginUser () {
		
		System.out.println("Login to the Grid");
		
		try {
			// if valid proxy exists, use it
			File proxy = new File(DEFAULT_PROXY_FILENAME);
			if (proxy.exists()) {
				GlobusCredential oldCred = ProxyUtil.loadProxy(DEFAULT_PROXY_FILENAME);
				Long timeLeft = oldCred.getTimeLeft();

				if (timeLeft > 0) {
					System.out.println("Using existing credential with " + timeLeft + " seconds remaining");
					this.cred = oldCred;
					return;
				}
				
			}
			
			UserActions userActions = new UserActions( props.getProperty(DEFAULT_DORIAN_SERVICE_URL_PROP));
		
			this.cred = userActions.loginUser();
			System.out.println("Identity = " + cred.getIdentity());
		
			
			ProxyUtil.saveProxy(cred, DEFAULT_PROXY_FILENAME);
			System.out.println("User credential saved to  = " + DEFAULT_PROXY_FILENAME);
			
			System.out.println("Login complete.");
			
		}
		catch (AxisFault af) {
			// TODO: Display appropriate client error
			System.out.println(af.getClass().getName() + ": " + af.getFaultString());
			
		}
		catch (Throwable e){
			// TODO: Display appropriate client error
			System.out.println(e.getClass().getName() + ": " + e.toString());
			e.printStackTrace();
		}
	
	}
	
	// search for services
	private EndpointReferenceType[] discoverCBMServices () {
		System.out.println("Discovering Grid Services");
		
		String indexServiceUrl = props.getProperty(DEFAULT_INDEX_SERVICE_URL_PROP);
		try {
			DiscoveryActions discActions = new DiscoveryActions(indexServiceUrl);
			
			// search for services
			EndpointReferenceType[] serviceEndpoints = discActions.searchCBMServices();
			if (null != serviceEndpoints && serviceEndpoints.length > 0) { 
				
				System.out.println ("Available services:");
				for (int i=0; i < serviceEndpoints.length; i++) {
					System.out.println("    " + i + ": " + serviceEndpoints[i].getAddress().toString());
				}
				
				return serviceEndpoints;
			}
			else {
				System.out.println("No matching Services found");
			}
			
			
		} catch (Exception e) {
			// TODO: Display appropriate client error
			System.out.println(e.getClass().getName() + ": " + e.toString());
		}
		
		return null;
	}

	private void queryDataService() {
		System.out.println("Query Data Services: ");
		
		System.out.println("1 : Select CBM service from the Index Service" );
		System.out.println("2 : Provide Local CBM service URL ");
		String localQueryMessage="Select service location";
		int localQuery=UserInteraction.getIntegerFromUser(localQueryMessage, 1, 2);
		
		EndpointReferenceType serviceEndpoint = null;

		if (localQuery == 2)
		{
			String localServiceURL = UserInteraction.getStringFromUser ("Provide the URL of the local service");
			try {
				serviceEndpoint= new EndpointReferenceType(new URI (localServiceURL));
			} catch (MalformedURIException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			// get data service list
			String indexServiceUrl = props.getProperty(DEFAULT_INDEX_SERVICE_URL_PROP);
			EndpointReferenceType[] eprs = null;
			try {
				DiscoveryActions discActions = new DiscoveryActions(indexServiceUrl);
				
				// search for services
				eprs = discActions.searchCBMServices();
				
				if (null != eprs && eprs.length > 0) {
					System.out.println ("Available CBM Data Services:");
					for (int i=0; i < eprs.length; i++) {
						System.out.println("    " + i + ": " + eprs[i].getAddress().toString());
					}
				}
				else {
					System.out.println("No matching Services found");
				}
			} catch (Exception e) {
				// TODO: Display appropriate client error
				System.out.println(e.getClass().getName() + ": " + e.toString());
			}
	
			// get service number for query
			int last = eprs.length -1;
			String message = "Select Service";
			int serviceNumber = UserInteraction.getIntegerFromUser(message, 0, last);
	
			// select the endpoint
		    serviceEndpoint = eprs[serviceNumber];
		}
		
		// Verify that user is authenticated for https
		String protocol = serviceEndpoint.getAddress().getScheme();
		if (protocol.equalsIgnoreCase("https")) {
			boolean authValid = checkAuthenticated();
			
			if (authValid == false) {
				System.out.println("You must login to perform this action against a secure service");
				return;
			}
		}
		
		// ask user for query against object or query from file
		System.out.println("1 : Select query object from list" );
		System.out.println("2 : Read CQL query from file");
		String message = "Select Query Type";
		int queryType = UserInteraction.getIntegerFromUser(message, 1, 2);
		
		if (queryType == QUERY_AGAINST_OBJECT) {
			int objectCount = displayDomainObjectNames(serviceEndpoint);	
			if (objectCount > 0) {
				// select an object to query
				message = "Select a object to query";
				int objectNumber = UserInteraction.getIntegerFromUser(message, 0, objectCount);
			
				// create object name
				String objectName = null;
				try {
					DomainModel domainModel = MetadataUtils.getDomainModel(serviceEndpoint);
					UMLClass[] umlClassCollection = domainModel.getExposedUMLClassCollection().getUMLClass();
				    objectName = umlClassCollection[objectNumber].getPackageName()+"."+umlClassCollection[objectNumber].getClassName();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
		
				if (serviceEndpoint.getAddress().getScheme().compareTo("http") == 0) {
					DataServiceActions.invokeNonSecureService( serviceEndpoint, objectName);
				}
				else {
					try {
						DataServiceActions.invokeSecureService( serviceEndpoint, this.cred, objectName);
					} catch (Exception e) {
						//TODO: Display appropriate client error
						e.printStackTrace();
					}
				}
			}
		}
		
		if (queryType == QUERY_FROM_FILE) {
			
			message = "Provide CQL Filename";
			String filename = UserInteraction.getStringFromUser(message);
			
			// verify file existence 
			File queryFile = new File(filename);
			if (!queryFile.exists()) {
				System.out.println ("File does not exist: " + queryFile);
				return;
			}
			
			try {
				// deserialize the query
				CQLQuery query = (CQLQuery) Utils.deserializeObject(
				         new FileReader(queryFile), CQLQuery.class);
				
				CQLQueryResults queryResults = null;
				
				if (serviceEndpoint.getAddress().getScheme().compareTo("http") == 0) {
					queryResults = DataServiceActions.invokeNonSecureService( serviceEndpoint, query);
				}
				else {
					GlobusCredential cred;
					try {
						queryResults = DataServiceActions.invokeSecureService( serviceEndpoint, this.cred, query);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			
				// write the result to a local file
			    Utils.serializeDocument("queryResults.xml", queryResults, 
						DataServiceConstants.CQL_RESULT_COLLECTION_QNAME);
			    
			    System.out.println ("Query results written to queryResults.xml");
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}	
	
	private boolean checkAuthenticated () {
		
		// load the proxy if it exists
		if (this.cred == null && new File(DEFAULT_PROXY_FILENAME).exists()) {
			try {
				this.cred = ProxyUtil.loadProxy(DEFAULT_PROXY_FILENAME);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			
			// proxy is expired
			if (this.cred.getTimeLeft() < 1) {
				this.cred = null;
				return false;
			}
			
			// proxy exists and is valid
			return true;
		}
		else {
			return false;
		}
	}
	
	private int  displayDomainObjectNames (EndpointReferenceType epr) {
		DomainModel domainModel;
		UMLClass[] umlClassCollection = null;
		try {
			domainModel = MetadataUtils.getDomainModel(epr);
			umlClassCollection = domainModel.getExposedUMLClassCollection().getUMLClass();
			
			for (int i=0; i < umlClassCollection.length; i++) {
			    String objectName = umlClassCollection[i].getPackageName()+"."+umlClassCollection[i].getClassName();
				System.out.println("    " + i + ": " + objectName);
			}
			
			return umlClassCollection.length-1;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("ERROR: " + e.getClass().getName() + ": " + e.toString());
		}
		
		return 0;
	}

	private void displayOptions () {
		
		// an ugly way to avoid stack traces interfering with
		// the output of this "menu"
		long t0, t1;
        t0 =  System.currentTimeMillis();
        do{
            t1 = System.currentTimeMillis();
        }
        while ((t1 - t0) < (2 * 1000));
		
		System.out.println("--------------------------");
		System.out.println("1 : Sync with Trust Fabric");
		System.out.println("2 : Login to Grid");
		System.out.println("3 : Search for CBM Services in Index Service");
		System.out.println("4 : Query a CBM Data Service");
		System.out.println("5: Quit");
	}
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		GridClient client = new GridClient();
		
		int userInput = -1;
		
		for (;;) {
			// prompt for new operation
			client.displayOptions();
			String message = "Select client action: ";
			userInput = UserInteraction.getIntegerFromUser (message, 1, 5);
			
			System.out.println();
			
			if (userInput == 5) {
				System.out.println("quitting");
				break;
			}
  
			// perform the operation
			if (userInput == 1) {
				client.syncTrust();
			}
			else if (userInput == 2) {
				client.loginUser();
			}
			else if (userInput == 3) {
				client.discoverCBMServices();
			}
			else if (userInput == 4) {
				client.queryDataService();
			}
			else {
	            System.out.println("Invalid entry.");
	        }
			System.out.println(); 
		}
	}


}

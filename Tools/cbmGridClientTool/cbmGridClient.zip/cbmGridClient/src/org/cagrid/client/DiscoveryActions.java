package org.cagrid.client;

import gov.nih.nci.cagrid.discovery.client.DiscoveryClient;
import gov.nih.nci.cagrid.metadata.common.UMLClass;
import gov.nih.nci.cagrid.metadata.exceptions.QueryInvalidException;
import gov.nih.nci.cagrid.metadata.exceptions.RemoteResourcePropertyRetrievalException;
import gov.nih.nci.cagrid.metadata.exceptions.ResourcePropertyRetrievalException;

import org.apache.axis.message.addressing.EndpointReferenceType;
import org.apache.axis.types.URI.MalformedURIException;

public class DiscoveryActions {
	
	private DiscoveryClient discClient = null;

	public DiscoveryActions(String serviceUrl) throws MalformedURIException{
		this.discClient = new DiscoveryClient(serviceUrl);
	}
	
	public EndpointReferenceType[] getServices () throws RemoteResourcePropertyRetrievalException, QueryInvalidException, ResourcePropertyRetrievalException {
	    	EndpointReferenceType[] allServices = discClient.getAllServices(true);
	    	return allServices;
	}
	
	public EndpointReferenceType[]  getDataServices () throws RemoteResourcePropertyRetrievalException, QueryInvalidException, ResourcePropertyRetrievalException {
		EndpointReferenceType[] dataServices = discClient.getAllDataServices();
		return dataServices;
	}
	
	public EndpointReferenceType[]  getAnalyticalServices () throws RemoteResourcePropertyRetrievalException, QueryInvalidException, ResourcePropertyRetrievalException {
		EndpointReferenceType[] analyticalServices = discClient.getAllAnalyticalServices();
		return analyticalServices;
	}	
	
	public EndpointReferenceType[] getServicesByInputOperation (UMLClass umlClass) throws RemoteResourcePropertyRetrievalException, QueryInvalidException, ResourcePropertyRetrievalException {
		
		EndpointReferenceType[] searchedServices = discClient.discoverServicesByOperationInput(umlClass);
		return searchedServices;
	}
	
	public EndpointReferenceType[] searchServices () throws RemoteResourcePropertyRetrievalException, QueryInvalidException, ResourcePropertyRetrievalException, MalformedURIException {
		String searchTerm = UserInteraction.getStringFromUser("Enter Search Term");
		
		System.out.println ("Searching for '" + searchTerm + "' services");
    	EndpointReferenceType[] searchedServices = null;
    	
    	searchedServices = discClient.discoverServicesBySearchString(searchTerm);
    	
    	return searchedServices;
	}
	
	public EndpointReferenceType[] searchCBMServices () throws RemoteResourcePropertyRetrievalException, QueryInvalidException, ResourcePropertyRetrievalException, MalformedURIException {
		String searchTerm = "CBM";
		
		System.out.println ("Searching for '" + searchTerm + "' services");
    	EndpointReferenceType[] searchedServices = null;
    	
    	searchedServices = discClient.discoverServicesBySearchString(searchTerm);
    	
    	return searchedServices;
	}

	public EndpointReferenceType[] searchServices (String searchTerm) throws RemoteResourcePropertyRetrievalException, QueryInvalidException, ResourcePropertyRetrievalException, MalformedURIException {	
		
		System.out.println ("Searching for '" + searchTerm + "' services");
    	EndpointReferenceType[] searchedServices = discClient.discoverServicesBySearchString(searchTerm);
    	
    	return searchedServices;
	}
}
